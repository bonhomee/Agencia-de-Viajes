<footer class="footer">
  <img src="img/logo.png" alt="Footer Logo" class="logo-footer" />
  <p>Enjoy the touring</p>
  <div class="social-icons">
    <a href="https://facebook.com" target="_blank">
      <img src="img/facebook.png" alt="Facebook" />
    </a>
    <a href="https://instagram.com" target="_blank">
      <img src="img/instagram.png" alt="Instagram" />
    </a>
    <a href="https://twitter.com" target="_blank">
      <img src="img/twitter.png" alt="Twitter" />
    </a>
  </div>
</footer>
